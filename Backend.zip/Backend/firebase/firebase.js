import admin from "firebase-admin";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Read Service Account JSON
const serviceAccount = JSON.parse(
  fs.readFileSync(
    path.join(__dirname, "serviceAccountKey.json"),
    "utf8"
  )
);

// Initialize Firebase only once
if (!admin.apps.length) {
  admin.initializeApp({
    credential: admin.credential.cert(serviceAccount),
  });
}

// Firestore Database
const db = admin.firestore();

export { admin, db };