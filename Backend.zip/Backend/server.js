import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import { db } from "./firebase/firebase.js";

dotenv.config();

const app = express();

app.use(cors());
app.use(express.json());

app.get("/", (req, res) => {
  res.json({
    success: true,
    message: "QueueTrack Backend Running 🚀",
  });
});

// Firebase Test
app.get("/test-firebase", async (req, res) => {
  try {
    const snapshot = await db.collection("orders").get();

    res.json({
      success: true,
      totalOrders: snapshot.size,
    });
  } catch (err) {
    res.status(500).json({
      success: false,
      error: err.message,
    });
  }
});

const PORT = process.env.PORT || 5000;

app.listen(PORT, () => {
  console.log(`🚀 Server Running on http://localhost:${PORT}`);
});